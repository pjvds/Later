window.addEventListener('load', function () {
    LaterPageAction.init();
});