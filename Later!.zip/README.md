# Later!

Later! is a Chrome Extension that enables you to bookmark a page to Read It Later.
It adds a small icon to the address bar that you can click to mark the current page for later reading.

## Features

* Plain dead simple! Just click and forget.
* Intuitive! Feedback given by icons, no pop ups or other annoying things.
* Configuration-less! We have big configuration screens as much as you do.

<<<<<<< HEAD
## Installation
=======
* Dead simple to use
* No configuration
* Handle non-direct url situations; like Google Reader

### Non-direct url situations
This are situations where a website page url doesn't point to a article. For example, when you 
read a article in Google Reader. The current url point to the stream of articles. This could be
the unread, favored or all articles in a certain category. In these situation sending the current
url to ReadItLater doesn't work. You want to send the perma url to it instead. This are scenario's
we want to support.

Currently we support none.
>>>>>>> ff9c03a2f0a6007ae3388818717393c0f2815df2

**TODO: ADD INSTALLATION INFO HERE**

<<<<<<< HEAD
## Technical

Later! is build with HTML, Javascript and uses the Chrome.* API's.

## More info

Find more at: [later.craftify.nl](http://later.craftify.nl).
=======
Later! is build with HTML, Javascript and uses the [Chrome.* API's](http://code.google.com/chrome/extensions/api_index.html).
>>>>>>> ff9c03a2f0a6007ae3388818717393c0f2815df2
